var config = {
    map: {
        '*':{
                donate_js:'PPhong_ProductDonate/js/donate_js',
            }
        },
    shim:{
            'donate_js':{
                                 deps: ['jquery']
                             }
        }
};